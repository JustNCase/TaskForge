# TaskForge AI
Solo-owner rewards and lead marketplace SaaS.

## Core Revenue
- Offerwalls
- Lead generation
- AI mystery shopping
- Referrals
- Premium subscriptions

## MVP
- Auth
- Dashboard
- Wallet
- Referrals
- Withdrawals
- Admin panel
