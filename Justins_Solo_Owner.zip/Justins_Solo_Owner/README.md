# Justin's Solo Owner Folder

Contains:
- Business plan
- Architecture
- Starter schema

Next step: build Next.js application and deploy.
