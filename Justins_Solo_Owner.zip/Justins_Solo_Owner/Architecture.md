# Architecture

Frontend: Next.js
Backend: Supabase
Payments: Stripe
Hosting: Vercel

Tables:
users
earnings
withdrawals
business_leads
offers
referrals
