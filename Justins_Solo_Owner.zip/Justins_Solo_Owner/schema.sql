
create table users (
 id uuid primary key,
 email text,
 username text,
 balance numeric default 0
);
